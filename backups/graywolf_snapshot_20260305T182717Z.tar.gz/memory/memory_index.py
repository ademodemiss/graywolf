import json
from collections import defaultdict
from pathlib import Path


MEMORY_DB = Path("/home/adem/graywolf/memory/agent_memory.jsonl")
INDEX_DB = Path("/home/adem/graywolf/memory/agent_memory_index.json")


def build_index() -> dict:
    index = defaultdict(list)
    if not MEMORY_DB.exists():
        return {"status": "ok", "entries": 0}

    for line in MEMORY_DB.read_text(encoding="utf-8").splitlines():
        try:
            row = json.loads(line)
        except Exception:
            continue
        ts = row.get("ts")
        goal = str(row.get("goal", ""))
        for token in goal.lower().split():
            index[token].append({"ts": ts, "goal": goal})

    payload = {"keywords": index}
    INDEX_DB.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    return {"status": "ok", "entries": sum(len(v) for v in index.values())}


if __name__ == "__main__":
    print(json.dumps(build_index(), ensure_ascii=False))
