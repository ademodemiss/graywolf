import json
from pathlib import Path


MEMORY_DB = Path("/home/adem/graywolf/memory/agent_memory.jsonl")


def search_memory(query: str) -> list[dict]:
    if not MEMORY_DB.exists():
        return []
    q = (query or "").lower()
    out = []
    for line in MEMORY_DB.read_text(encoding="utf-8").splitlines():
        try:
            row = json.loads(line)
        except Exception:
            continue
        blob = " ".join(str(row.get(k, "")) for k in ["goal", "workflow", "result", "error", "decision"]).lower()
        if q in blob:
            out.append(row)
    return out


if __name__ == "__main__":
    print(json.dumps(search_memory("demo"), ensure_ascii=False))
