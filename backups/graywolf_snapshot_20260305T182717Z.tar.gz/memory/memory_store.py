import datetime
import json
from pathlib import Path


MEMORY_DB = Path("/home/adem/graywolf/memory/agent_memory.jsonl")


def store_memory(goal: str, workflow: str, result: str, error: str = "", decision: str = "") -> dict:
    MEMORY_DB.parent.mkdir(parents=True, exist_ok=True)
    row = {
        "ts": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "goal": goal,
        "workflow": workflow,
        "result": result,
        "error": error,
        "decision": decision,
    }
    with open(MEMORY_DB, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")
    return row


if __name__ == "__main__":
    print(json.dumps(store_memory("demo-goal", "demo-workflow", "ok", "", "continue"), ensure_ascii=False))
